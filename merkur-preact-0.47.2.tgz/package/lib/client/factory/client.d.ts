import { render, hydrate } from 'preact';
import { WidgetParams, defineWidget } from '@merkur/core';
declare module '@merkur/core' {
    interface WidgetDependencies {
        render: typeof render;
        hydrate: typeof hydrate;
    }
}
/**
 * Client Factory for creating merkur widgets with preact renderer.
 */
export declare function createPreactWidget({ name, version, $dependencies, viewFactory, ...restProps }: Parameters<typeof defineWidget>[0]): (widgetParams: WidgetParams) => Promise<import("@merkur/core").Widget>;
