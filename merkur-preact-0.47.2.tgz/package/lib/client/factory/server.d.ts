import { WidgetParams, defineWidget } from '@merkur/core';
/**
 * Server Factory for creating merkur widgets with preact renderer.
 */
export declare function createPreactWidget({ viewFactory, $dependencies, ...restProps }: Parameters<typeof defineWidget>[0]): (widgetParams: WidgetParams) => import("@merkur/core").Widget;
